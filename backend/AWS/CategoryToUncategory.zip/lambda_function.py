import json
import psycopg2
from psycopg2.extras import RealDictCursor
import os
username=os.getenv('DBUsername')
passcode=os.getenv('DBPassword')
hostadress=os.getenv('DBHost')
DBname=os.getenv('DBName')
con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        
        con = psycopg2.connect(
            host=hostadress,
            database=DBname,
            user=username,
            password=passcode
            
         )
        
    return con


def lambda_handler(event, context):
    # TODO implement
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)

    try:    
        SQLQuery= 'UPDATE Items SET parentcategoryid = %s, subcategoryid = %s where parentcategoryid=%s and organizationid=%s;'
        parameters = (-1, -1, event['parentcategoryid'], event['organizationid'])
        curr.execute(SQLQuery, parameters)
        conn.commit()
    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'Error moving items',
             'error': json.dumps(str(e))
         }
    finally:
        curr.close()
        conn.close()
       
    return {
            'statusCode': 200,
            'body': 'items moved successfully'
        }
       

    

    

print(lambda_handler("", "fv"))