import json
import psycopg2
from psycopg2.extras import RealDictCursor
import requests
import os
username=os.getenv('DBUsername')
passcode=os.getenv('DBPassword')
hostadress=os.getenv('DBHost')
DBname=os.getenv('DBName')

APIKey=os.getenv('Token')
OpenAIEnd=os.getenv('API')



con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        
        con = psycopg2.connect(
            host=hostadress,
            database=DBname,
            user=username,
            password=passcode
            
         )
        
    return con


def lambda_handler(event, context):
  
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)
    SuggestResponseList=[]

    try:    
    
        Query=''' 
        SELECT c.id, c.categoryname
        FROM category c
        LEFT JOIN deletedcategory d 
        ON c.id = d.categoryid AND c.organizationid = d.organizationid
        WHERE c.organizationid =%s
        AND d.categoryid IS NULL
        AND d.organizationid IS NULL
        AND c.parentcategory=%s
        '''
        
        parameters = (1, 0)         
        curr.execute(Query, parameters)
        Catergory= curr.fetchall()

        ItemIds=str(event['id']).split(',')
    
      
        headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {APIKey}'
        }

        
        for id in ItemIds:
            Query='''
            select item_name, description from items where item_id=%s;
            '''
            parameters=(id,)
            curr.execute(Query, parameters)
            ItemDetails= curr.fetchall()[0]

        
            ItemName=ItemDetails['item_name']
            ItemDescription=ItemDetails['description']

    
            data = {
                "model": "gpt-3.5-turbo",
                "messages": [{"role": "system", "content": "You will be provided with a item name and item description, and your task is to classify the item into one of the following categories "+json.dumps(Catergory)+". Return  the id and categoryname as answer"},
                            {"role": "user", "content": "Item Name: "+ItemName +",Item Description: "+ ItemDescription } ],
                "temperature": 0.7                
            }
            try:
                response = requests.post(OpenAIEnd, json=data, headers=headers)
                response_data = response.json()
                #print(response_data)
                SuggestedCategory=  response_data['choices'][0]['message']['content']
                SuggestedCategory=json.loads(str(SuggestedCategory))
            except requests.exceptions.RequestException as e:
                print(f"Error making request: {e}")
                continue

    
        
            
            Query=''' 
            SELECT c.id, c.categoryname
            FROM category c
            LEFT JOIN deletedcategory d 
            ON c.id = d.categoryid AND c.organizationid = d.organizationid
            WHERE c.organizationid =%s
            AND d.categoryid IS NULL
            AND d.organizationid IS NULL
            AND c.parentcategory=%s
            '''
        
            parameters = (1, SuggestedCategory['id'])
                    
            curr.execute(Query, parameters)
            Subcategory= curr.fetchall()



            print(Subcategory)
            if len(Subcategory) > 0:
                data = {
                "model": "gpt-3.5-turbo",
                "messages": [{"role": "system", "content": "You will be provided with a item name and item description, and your task is to classify to one of the following categories "+json.dumps(Subcategory)+".  Return  the id and categoryname as answer"},
                            {"role": "user", "content": "Item Name "+ItemName +"Item Description "+ ItemDescription } ],
                "temperature": 0.7
                            
                }
                try:
                    response = requests.post(OpenAIEnd, json=data, headers=headers)
                    response_data = response.json()
                    #print(response_data)
                    SuggestedSubCategory=  response_data['choices'][0]['message']['content']
                    SuggestedSubCategory=json.loads(str(SuggestedSubCategory))
                except requests.exceptions.RequestException as e:
                    print(f"Error making request: {e}")
                    continue
            else:
                SuggestedSubCategory=[]
            
            
            recommendation={
                "id": str(id),
                "category": SuggestedCategory,
                "subcategory":SuggestedSubCategory
            }
            SuggestResponseList.append(recommendation)


        
        


    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'Error Fetch Categories / Sub Categoroes',
             'error': json.dumps(str(e))
         }
    finally:
        curr.close()
        conn.close()
       
    return {
            'statusCode': 200,
            'body': 'Successfully Recommended Category and subcategory',
            'response': SuggestResponseList
        
        }
       

