import json
import jwt
from datetime import datetime


Level1=["FetchCategory", "Search", "CategoryFilter","FetchByID", "FetchByColour", "FetchAll", "SubcategoryFilter", "CategoryFilter", "permissionnot"]
Level2=["FetchCategory", "Search", "CategoryFilter","FetchByID", "FetchByColour", "FetchAll", "SubcategoryFilter", "CategoryFilter", "Generatebarcode", "ModifyCategoryName", "GenerateQrcode", "DeleteColour", "SubcategoryToUncategorized", "CategoryToUncategorized", "AddItemToColour","AddColour", "DeleteItem", "RecommendCategory", "AddCategory", "RecentlyAdded", "EditItem", "DeleteCategory", "AddItem", "permissionnot"]
Level3=[]
Level4=[]



def search_for_role(role_list, target_role):
   
    target_role = target_role.lower()
    return any(role.lower() == target_role for role in role_list)



def lambda_handler(event, context):

    #need to check token is not expired

    #check if token is authenticatic
   
    decoded_token = jwt.decode(event['authorizationToken'], options={"verify_signature": False})

    if datetime.now() >= datetime.fromtimestamp(decoded_token['exp']) :
        return json.loads(generatePolicy('user', 'Deny', event['methodArn']))

    roles=decoded_token['realm_access']['roles']

    effect="Deny"
    

    if search_for_role(roles,"admin")  or search_for_role(roles,"manager") :
        effect='Allow'
    
    elif search_for_role(roles,"normal_user") or search_for_role(roles, 'offline_access'): 
        if search_for_role(Level2, event['methodArn'].rsplit('/', 1)[-1]):
            effect='Allow'
        else:
            effect='Deny'
    else: 
        if search_for_role(Level1,  event['methodArn'].rsplit('/', 1)[-1]):
            effect='Allow'
        else:
            effect='Deny'


    try:
        return json.loads(generatePolicy('user', effect, event['methodArn']))
    except BaseException:
        print('unauthorized')
        return 'unauthorized2' 

    


def generatePolicy(principalId, effect, resource):
    authResponse = {}
    authResponse['principalId'] = principalId
    if (effect and resource):
        policyDocument = {}
        policyDocument['Version'] = '2012-10-17'
        policyDocument['Statement'] = []
        statementOne = {}
        statementOne['Action'] = 'execute-api:Invoke'
        statementOne['Effect'] = effect
        statementOne['Resource'] = resource
        policyDocument['Statement'] = [statementOne]
        authResponse['policyDocument'] = policyDocument
    authResponse['context'] = {
        "stringKey": "stringval",
        "numberKey": 123,
        "booleanKey": True
    }
    authResponse_JSON = json.dumps(authResponse)
    return authResponse_JSON



event={
  "authorizationToken": "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICI5eUVEQWRLZmFNVHhqR1g5MTlPS21LU1RGamxtMHk0NlZqY09LblpFbFlrIn0.eyJleHAiOjE3MjE4OTQ1ODQsImlhdCI6MTcyMTg5MDk4NCwianRpIjoiNjQzYjg0NGQtOGE0Ni00ZDc0LTlhYmUtYzQxOTQ5MWI1Y2RmIiwiaXNzIjoiaHR0cDovL2xvY2FsaG9zdDo4MDgwL3JlYWxtcy9teXJlYWxtIiwiYXVkIjpbImJyb2tlciIsImFjY291bnQiXSwic3ViIjoiMDk2Y2NiNzQtNzVlMC00NDhmLWI0ZGUtOWI3NzYyMWY1YWQ4IiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiTG9naW4iLCJzaWQiOiJkMjNlZDliZS02OTQwLTQ2NDQtOTYyYi00Y2ExZDY0NGM2MDEiLCJhY3IiOiIxIiwiYWxsb3dlZC1vcmlnaW5zIjpbIi8qIl0sInJlYWxtX2FjY2VzcyI6eyJyb2xlcyI6WyJkZWZhdWx0LXJvbGVzLW15cmVhbG0iLCJvZmZsaW5lX2FjY2VzcyIsInVtYV9hdXRob3JpemF0aW9uIl19LCJyZXNvdXJjZV9hY2Nlc3MiOnsiYnJva2VyIjp7InJvbGVzIjpbInJlYWQtdG9rZW4iXX0sImFjY291bnQiOnsicm9sZXMiOlsibWFuYWdlLWFjY291bnQiLCJ2aWV3LWFwcGxpY2F0aW9ucyIsInZpZXctZ3JvdXBzIiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJkZWxldGUtYWNjb3VudCIsInZpZXctcHJvZmlsZSJdfX0sInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwibmFtZSI6InZpY3RvciB6aG91IiwicHJlZmVycmVkX3VzZXJuYW1lIjoidmljdG9yIiwiZ2l2ZW5fbmFtZSI6InZpY3RvciIsImZhbWlseV9uYW1lIjoiemhvdSIsImVtYWlsIjoidTIxNTI1OTM2QHR1a3MuY28uemEifQ.kx98xCIMcgAJnY03Qv7cS_8qqDybjRrTOXX_6myPTGs6kElkN96AnSAdR49mm6ZDsU7BltJqiGRV3kRaYv5H05Ku-90kxlyjs-u9cs3ke_FqT_EAkIaykZMNDTgkSB7O2dAffKsEVvdzAYELT4y6SsfOJArZGRtmJRK32cEVnM2vKyiPTVrsda0Q0wGDRYD0xQZsYdGTjMJS7wSko9BPw13MxNQXtLsb0qOK2VqfTntQckYH91RuNwx8CBMboze6hjNfrWak9Q4BdIWO4JG-dAK8_607FnNxeTGi08eYH8AJ03wO39aIF43Jgc0XMC7tKs6mhpRV0fN-Q-2NzTgU9g",
  "principalId": "AB",
  "methodArn": "arn:aws:execute-api:us-east-1:123456789012:abcd1234/prod/GET/user/permissio",
  "path": "poiuhg/[lpkojnhb/poijh"
}

print(lambda_handler(event, ""))