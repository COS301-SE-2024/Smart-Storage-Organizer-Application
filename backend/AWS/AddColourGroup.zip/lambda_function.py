import json
import psycopg2
from psycopg2.extras import RealDictCursor
import os

username=os.getenv('DBUsername')
passcode=os.getenv('DBPassword')
hostadress=os.getenv('DBHost')
DBname=os.getenv('DBName')
con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        
        con = psycopg2.connect(
            host=hostadress,
            database=DBname,
            user=username,
            password=passcode
            
         )
        
    return con

def lambda_handler(event, context):
    # TODO implement
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)

    try:         
        Query='''
        INSERT INTO colours (colourcode, organizationid, description, title,createremail) VALUES (%s, %s, %s, %s, %s) RETURNING *;
        '''
        parameters = (event['colourcode'], event['organizationid'], event['description'],event['title'],event['createremail'])
        curr.execute(Query, parameters)
        conn.commit()
        insertedColour=curr.fetchall()
        insertedColour=insertedColour[0]
        insertedColour['created_at']=insertedColour['created_at'].strftime('%Y-%m-%d %H:%M:%S')

        
    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'unsuccessful attempt to add colour',
             'error': json.dumps(str(e))
         }
    finally:
        curr.close()
        conn.close()
       
    return {
             'statusCode': 200,
             'status': 'successfully Added colour group',
             'colour': json.dumps(insertedColour)
        
         }
