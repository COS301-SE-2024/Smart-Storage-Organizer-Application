import json
import psycopg2
from psycopg2.extras import RealDictCursor
import os

username=os.getenv('DBUsername')
passcode=os.getenv('DBPassword')
hostadress=os.getenv('DBHost')
DBname=os.getenv('DBName')
con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        
        con = psycopg2.connect(
            host=hostadress,
            database=DBname,
            user=username,
            password=passcode
            
         )
        
    return con


def lambda_handler(event, context):
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)
 
  
    try:    
        SQLQuery='select item_id, item_name,description, quanity,location, email, parentcategoryid, subcategoryid from items where true  ORDER BY created_at ASC;'
        parameters = ()
        curr.execute(SQLQuery, parameters)
        items=curr.fetchall()
        conn.commit()

    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'Error FIlter By Category item',
             'error': json.dumps(str(e))
         }
    finally:
        curr.close()
        conn.close()
       
    return json.dumps(items)
            


