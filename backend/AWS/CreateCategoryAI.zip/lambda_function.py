import json
import psycopg2
from psycopg2.extras import RealDictCursor
import requests
import os
username=os.getenv('DBUsername')
passcode=os.getenv('DBPassword')
hostadress=os.getenv('DBHost')
DBname=os.getenv('DBName')

APIKey=os.getenv('Token')
OpenAIEnd=os.getenv('API')



con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        
        con = psycopg2.connect(
            host=hostadress,
            database=DBname,
            user=username,
            password=passcode
            
         )
        
    return con


def lambda_handler(event, context):
  
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)
    SuggestResponseList=[]

    try:    
    
        
        headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {APIKey}'
        }

        
        ItemName=event['item_name']
        ItemDescription=event['description']

                

        if event['parentcategory'] == "":
            Query=''' 
            SELECT c.id, c.categoryname
            FROM category c
            LEFT JOIN deletedcategory d 
            ON c.id = d.categoryid AND c.organizationid = d.organizationid
            WHERE (c.organizationid =%s or c.organizationid =%s)
            AND d.categoryid IS NULL
            AND d.organizationid IS NULL
            AND c.parentcategory=%s
            '''
            
            parameters = (0, event['organizationid'], 0)         
            curr.execute(Query, parameters)
            Catergory= curr.fetchall() 
            data = {
            "model": "gpt-3.5-turbo",
            "messages": [{"role": "system", "content": "You will be provided with a item name and item description, and your task is produce a category name where i can categorize this item. Note dont give a category name in or similar to the following"+json.dumps(Catergory)},
                        {"role": "user", "content": "Item Name "+ItemName +"Item Description "+ ItemDescription } ],
            "temperature": 0.7           
            }
        else:
            Query=''' 
            SELECT c.id, c.categoryname
            FROM category c
            LEFT JOIN deletedcategory d 
            ON c.id = d.categoryid AND c.organizationid = d.organizationid
            WHERE (c.organizationid =%s or c.organizationid =%s)
            AND d.categoryid IS NULL
            AND d.organizationid IS NULL
            AND c.parentcategory=%s
            '''
    
            parameters = (0, event['organizationid'], event['parentcategory'])
            curr.execute(Query, parameters)
            Subcatergory= curr.fetchall()
            data = {
            "model": "gpt-3.5-turbo",
            "messages": [{"role": "system", "content": "You will be provided with a item name and item description, and your task is produce a sub category name where i can categorize this item. Note dont give a subcategory name in or similar to the following"+json.dumps(Subcatergory)},
                        {"role": "user", "content": "Item Name "+ItemName +"Item Description "+ ItemDescription } ],
            "temperature": 0.7           
            }
        
        try:
            response = requests.post(OpenAIEnd, json=data, headers=headers)
            response_data = response.json()
            Suggested=  response_data['choices'][0]['message']['content']
        
        except requests.exceptions.RequestException as e:
            print(f"Error making request: {e}")
            
        
    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'Error Fetch Categories / Sub Categoroes',
             'error': json.dumps(str(e))
         }
    finally:
        curr.close()
        conn.close()
       
    return {
            'statusCode': 200,
            'body': 'Successfully Recommended Category and subcategory',
            'response': Suggested
        
        }