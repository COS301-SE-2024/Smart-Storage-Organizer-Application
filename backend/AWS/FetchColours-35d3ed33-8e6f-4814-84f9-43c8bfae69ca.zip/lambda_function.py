import json
import psycopg2
from psycopg2.extras import RealDictCursor
import os

username=os.getenv('DBUsername')
passcode =os.getenv('DBPassword')
hostadress=os.getenv('DBHost')
DBname=os.getenv('DBName')
con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        
        con = psycopg2.connect(
            host=hostadress,
            database=DBname,
            user=username,
            password=passcode
            
         )
        
    return con


def lambda_handler(event, context):
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)
    
  
    try:    
        SQLQuery='select * from colours where organizationid=%s;'
        parameters = (1,)
        curr.execute(SQLQuery, parameters)
        items=curr.fetchall()
        for item in items:
            serialized_date = item['created_at'].strftime('%Y-%m-%d %H:%M:%S')
            item['created_at']=  serialized_date
        
        conn.commit()

    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'Error returning colours',
             'error': json.dumps(str(e))
         }
    finally:
        curr.close()
        conn.close()
       
    return {
            'statusCode': 200,
            'body': json.dumps(items),
            'message':"Successfully returned colourgroup"
        }

