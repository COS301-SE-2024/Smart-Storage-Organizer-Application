import json
import psycopg2
from psycopg2.extras import RealDictCursor
import os

username=os.getenv('DBUsername')
passcode=os.getenv('DBPassword')
hostadress=os.getenv('DBHost')
DBname=os.getenv('DBName')
con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        
        con = psycopg2.connect(
            host=hostadress,
            database=DBname,
            user=username,
            password=passcode
            
         )
        
    return con

def lambda_handler(event, context):
   
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)

    try:
        Query=''' 
        SELECT c.id, c.categoryname, c.parentcategory, c.useremail, c.organizationid, c.icon
        FROM category c
        LEFT JOIN deletedcategory d 
        ON c.id = d.categoryid AND c.organizationid = d.organizationid
        WHERE (c.organizationid =%s or c.organizationid =%s )
        AND d.categoryid IS NULL
        AND d.organizationid IS NULL
        AND c.parentcategory=%s
        '''
        
        parameters = (event['organizationid'], 0,event['parentcategory'] )
                
        curr.execute(Query, parameters)
        records= curr.fetchall()  
        conn.commit()
    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'unsuccessful query',
             'error': json.dumps(str(e))
         }
    finally:
        curr.close()
        conn.close()
       
    return {
             'statusCode': 200,
             'status': 'successfully query',
             'body': json.dumps(records)
         }


