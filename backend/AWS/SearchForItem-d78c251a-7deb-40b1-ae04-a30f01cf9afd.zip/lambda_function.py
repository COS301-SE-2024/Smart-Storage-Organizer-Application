import json
import os
from opensearchpy import OpenSearch, RequestsHttpConnection, helpers,AWSV4SignerAuth



region = os.getenv('Region') 
host = os.getenv('SEHost') 
index = os.getenv('Index')
service = os.getenv('Service')


def get_opensearch_client():
    auth=(os.getenv('SEUsername'), os.getenv('SEPassword'))
    client = OpenSearch(
        hosts = [{'host': host, 'port': 443}],
        http_auth = auth,
        use_ssl = True,
        verify_certs = True,
        connection_class = RequestsHttpConnection,
        pool_maxsize = 20
    )

    return client

def lambda_handler(event, context):
    
    OS_client=get_opensearch_client()

    must_clauses = []
    should_clauses = []

    if event['parentcategoryid'] != '*':
        must_clauses.append({"term": {"parentcategoryid": event['parentcategoryid']}})

    if event['subcategoryid'] != '*':
        must_clauses.append({"term": {"subcategoryid": event['subcategoryid']}})

    if event['target'] != '*':
        should_clauses.append({"match": {"name": event['target']}})
        should_clauses.append({"match": {"description": event['target']}})

 

    bool_query = {"must": must_clauses}

    if should_clauses:
        bool_query["should"] = should_clauses
        bool_query["minimum_should_match"] = 1

    query = {
        "query": {
            "bool": bool_query
        }
    }

    response = OS_client.search(
        index='items',
        body=query
    )
    
    
   
    return {
        'statusCode': 200,
        'body': json.dumps(response['hits']['hits'])
    }