import json
import psycopg2
from psycopg2.extras import RealDictCursor
import os

con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        con = psycopg2.connect(
            host=os.environ.get('Host_address'),
            database=os.environ.get('DB_Name'),
            user=os.environ.get('Username'),
            password=os.environ.get('Password')
         )
    return con

def get_category_constraints(conn, curr, category_id):
    query = """
    SELECT u.categoryname
    FROM category u
    INNER JOIN unit_category_constraint uc ON u.id = uc.category_id
    WHERE uc.unit_id= %s;
    """

    curr.execute(query, (category_id,))
    results = curr.fetchall()
    if results:

        units = [{ 'name': row['categoryname']
                 } for row in results]
        return {
        'statusCode': 200,
        'body': json.dumps(results)
        }
    else:
        return {
            'statusCode': 404,
            'body': 'No category found for the given unit'
        }


def lambda_handler(event, context):
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)

    try:
        response=get_category_constraints(conn,curr,event['unit_id'])
    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'Error modifying item',
             'error': json.dumps(str(e))
         }
    finally:
       curr.close()
       conn.close()
    return response

event={
    "unit_id": 1
}

context={}
print(lambda_handler(event, context))