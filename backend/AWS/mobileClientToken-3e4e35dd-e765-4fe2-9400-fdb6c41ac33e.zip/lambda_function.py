import json

def lambda_handler(event, context):
    # Parse the incoming JSON request body
    body = json.loads(event['body'])

    id_token = body.get('idToken')
    access_token = body.get('accessToken')
    refresh_token = body.get('refreshToken')
    fcm_token = body.get('fcmToken')

    # Here, you would typically handle the tokens (e.g., store them, validate them, etc.)
    # For this example, we'll just log them
    print("ID Token:", id_token)
    print("Access Token:", access_token)
    print("Refresh Token:", refresh_token)
    print("FCM Token:", fcm_token)

    # Construct the response
    response = {
        'statusCode': 200,
        'body': json.dumps('Tokens updated successfully')
    }

    return response
