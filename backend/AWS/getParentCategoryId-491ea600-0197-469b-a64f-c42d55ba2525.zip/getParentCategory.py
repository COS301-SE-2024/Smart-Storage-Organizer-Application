import json
import psycopg2
from psycopg2.extras import RealDictCursor
import os

con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        con = psycopg2.connect(
            host=os.environ.get('Host_address'),
            database=os.environ.get('DB_Name'),
            user=os.environ.get('Username'),
            password=os.environ.get('Password')
         )
    return con

def getParentCategory(category,conn,curr):
    query="select parentcategory from category where id=%s"
    parameters=(category,)
    curr.execute(query,parameters)
    result=curr.fetchone()
    return result['parentcategory']

def lambda_handler(event, context):
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)
    p_id=0
    try:
        s_id=event['body']['categoryId']
        p_id=getParentCategory(s_id,conn,curr)
    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'Error modifying item',
             'error': json.dumps(str(e))
         }

    finally:
       curr.close()
       conn.close()
    return {
        'statusCode': 200,
        'body': p_id
    }

