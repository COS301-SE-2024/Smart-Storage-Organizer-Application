import json
import psycopg2
from psycopg2.extras import RealDictCursor
import os
import math

username=os.getenv('DBUsername')
passcode=os.getenv('DBPassword')
hostadress=os.getenv('DBHost')
DBname=os.getenv('DBName')
con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        
        con = psycopg2.connect(
            host=hostadress,
            database=DBname,
            user=username,
            password=passcode
            
         )
        
    return con


def lambda_handler(event, context):
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)
    limit=int(event['limit'])
    offset=limit*(int(event['offset'])-1)
  
    try:    
        SQLQuery='select item_id, item_name,description,colourcoding,barcode,qrcode,barcode, quanity,location, email, item_image, parentcategoryid, subcategoryid from items where true  ORDER BY created_at ASC LIMIT %s OFFSET %s;'
        parameters = (limit, offset)
        curr.execute(SQLQuery, parameters)
        items=curr.fetchall()
        SQLQuery='select count(*) from items;'
        parameters = ()
        curr.execute(SQLQuery, parameters)
        TotalPages=curr.fetchall()[0]['count']
        TotalPages=math.ceil(TotalPages/limit)
        conn.commit()

    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'Error FIlter By Category item',
             'error': json.dumps(str(e))
         }
    finally:
        curr.close()
        conn.close()
       
    return {
            'statusCode': 200,
            'body': json.dumps(items),
            'totalpage':TotalPages,
            'message':"Successfully Filtered"
        }


