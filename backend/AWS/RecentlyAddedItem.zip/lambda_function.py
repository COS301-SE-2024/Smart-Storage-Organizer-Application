import json
import psycopg2
from psycopg2.extras import RealDictCursor
import os
username=os.getenv('DBUsername')
passcode=os.getenv('DBPassword')
hostadress=os.getenv('DBHost')
DBname=os.getenv('DBName')
con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        
        con = psycopg2.connect(
            host=hostadress,
            database=DBname,
            user=username,
            password=passcode
            
         )
        
    return con

def lambda_handler(event, context):
    # TODO implement
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)
    limit=5
    offset=0

    try:    
        SQLQuery= 'Select * From Items Where email = %s and organizationid=%s  ORDER BY created_at DESC LIMIT %s OFFSET %s;'
        parameters = (event['email'], event['organizationid'],limit, offset )
        curr.execute(SQLQuery, parameters)
        items= curr.fetchall()
        for item in items:
            serialized_date = item['created_at'].strftime('%Y-%m-%d %H:%M:%S')
            item['created_at']=  serialized_date

        

        conn.commit()
    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'Error modifying item',
             'error': json.dumps(str(e))
         }
    finally:
        curr.close()
        conn.close()
       
    return {
            'statusCode': 200,
            'status': 'Fetch Query Successful',
            'body': json.dumps(items)
        }



