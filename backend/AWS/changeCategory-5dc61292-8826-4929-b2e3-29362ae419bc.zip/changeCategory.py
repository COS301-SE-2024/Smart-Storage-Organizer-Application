import json
import psycopg2
from psycopg2.extras import RealDictCursor
import os

con = None
def get_db_connection():
    global con
    if con is None or con.closed:
        con = psycopg2.connect(
            host=os.environ.get('Host_address'),
            database=os.environ.get('DB_Name'),
            user=os.environ.get('Username'),
            password=os.environ.get('Password')
         )
    return con

def changeCategory(parent_id,sub_parent_category_id,item_id,conn,curr):
        query="update items set parentcategoryid=%s ,subcategoryid=%s where item_id=%s"
        parameters=(parent_id,sub_parent_category_id,item_id)
        curr.execute(query,parameters)
        conn.commit()


def lambda_handler(event, context):
    conn = get_db_connection()
    curr = conn.cursor(cursor_factory = RealDictCursor)
    try:
        p_id=event['body']['parentCategoryId']
        s_id=event['body']['subCategoryId']
        i_d=event['body']['itemId']
        changeCategory(p_id,s_id,i_d,conn,curr)
    except Exception as e:
      conn.rollback()
      return {
             'statusCode': 500,
             'body': 'Error modifying item',
             'error': json.dumps(str(e))
         }
    
    finally:
       curr.close()
       conn.close()
    return {
        'statusCode': 200,
        'body': 'Item modified successfully'
    }

